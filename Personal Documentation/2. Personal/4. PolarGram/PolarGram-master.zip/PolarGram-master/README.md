# PolarGram
Combine the new and the old!

# CI/CD
![Back-end services](https://github.com/LarsvdBrandt/PolarGram/workflows/Back-end%20CI/badge.svg)
![Front-end](https://github.com/LarsvdBrandt/PolarGram/workflows/Front-end%20CI/badge.svg)  
Docker: https://hub.docker.com/u/434565
 
# Installation
This project is containerized in Docker and deployable with docker-compose. Clone the git repository, navigate to the "PolarGram" directory in the command line, and type "docker-compose up". The web application will be running at "localhost:3001".

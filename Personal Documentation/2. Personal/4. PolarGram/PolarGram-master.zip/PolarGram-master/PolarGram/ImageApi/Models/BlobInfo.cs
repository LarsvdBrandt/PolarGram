﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ImageApi.Models
{
    public class BlobInfo
    {
        public string Content { get; set; }
        public string ContentType { get; set; }
    }
}

﻿namespace ServiceReport
{
    public class Report
    {
        public string CommentContent { get; set; }
        public int Count { get; set; }
    }
}